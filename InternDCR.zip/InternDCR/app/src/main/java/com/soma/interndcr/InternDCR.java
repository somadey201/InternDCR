package com.soma.interndcr;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;


/**
 * Created by Rajesh on 12/19/2018.
 */

public class InternDCR extends AppCompatActivity {

    ProductGroupArrayInfo[] groupinfo;
    LiteratureArrayInfo[] litInfo;
    SampleArrayInfo[] sampleInfo;
    GiftArrayInfo[] giftInfo;

    groupAdapter groupAdapter;
    LitAdapter litAdapter;
    SampleAdapter sampleAdapter;
    GiftAdapter giftAdapter;

    private Handler handler = new Handler();
    SharedPreferencesClass storePreference;
    HttpConnectionClass httpClass;
    Spinner type, lit, ps, gft;
    String Url, masterserverResponse, Result;


    ArrayList<ProductGroupArrayInfo> productGroupArrayList = new ArrayList<ProductGroupArrayInfo>();
    ArrayList<LiteratureArrayInfo> literatureArrayList = new ArrayList<LiteratureArrayInfo>();
    ArrayList<SampleArrayInfo> sampleArrayList = new ArrayList<SampleArrayInfo>();
    ArrayList<GiftArrayInfo> giftArrayList = new ArrayList<GiftArrayInfo>();

    AlertDialogManager alert = new AlertDialogManager();


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        httpClass = new HttpConnectionClass(InternDCR.this);
        storePreference = new SharedPreferencesClass(getApplicationContext());


        Url = Configuration.BASE_URL
                + "appinion-dev/intern-dcr-data/master/data.json";

        type = findViewById(R.id.group);
        lit = findViewById(R.id.lit);
        ps = findViewById(R.id.ps);
        gft = findViewById(R.id.gft);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"done",Toast.LENGTH_LONG).show();
            }
        });

        new Thread(new MasterDataTask()).start();


    }


    public void groupList() {

        groupinfo = productGroupArrayList
                .toArray(new ProductGroupArrayInfo[productGroupArrayList
                        .size()]);

        groupAdapter = new groupAdapter(
                getBaseContext(), android.R.layout.simple_spinner_dropdown_item,
                groupinfo);
        type.setAdapter(groupAdapter);
    }

    public void litList() {

        litInfo = literatureArrayList
                .toArray(new LiteratureArrayInfo[literatureArrayList
                        .size()]);

        litAdapter = new LitAdapter(
                getBaseContext(), android.R.layout.simple_spinner_dropdown_item,
                litInfo);
        lit.setAdapter(litAdapter);

    }

    public void sampleList() {
        sampleInfo = sampleArrayList
                .toArray(new SampleArrayInfo[sampleArrayList
                        .size()]);
        sampleAdapter = new SampleAdapter(
                getBaseContext(), android.R.layout.simple_spinner_dropdown_item,
                sampleInfo);
        ps.setAdapter(sampleAdapter);

    }

    public void GiftList() {

        giftInfo = giftArrayList
                .toArray(new GiftArrayInfo[giftArrayList
                        .size()]);

        giftAdapter = new GiftAdapter(
                getBaseContext(), android.R.layout.simple_spinner_dropdown_item,
                giftInfo);
        gft.setAdapter(giftAdapter);
    }


    public class groupAdapter extends
            ArrayAdapter<ProductGroupArrayInfo> {
        public groupAdapter(Context ctx, int txtViewResourceId,
                            ProductGroupArrayInfo[] objects) {
            super(ctx, txtViewResourceId, objects);
        }

        @Override
        public View getDropDownView(int position, View cnvtView, ViewGroup prnt) {
            return getCustomView(position, cnvtView, prnt);
        }

        @Override
        public View getView(int pos, View cnvtView, ViewGroup prnt) {
            return getCustomView(pos, cnvtView, prnt);
        }

        public View getCustomView(int position, View convertView,
                                  ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View mySpinner = inflater.inflate(R.layout.custom_spinner,
                    parent, false);
            TextView main_text = (TextView) mySpinner
                    .findViewById(R.id.text_main_seen);
            main_text.setText(groupinfo[position].pg);

            return mySpinner;
        }
    }

    public class LitAdapter extends
            ArrayAdapter<LiteratureArrayInfo> {
        public LitAdapter(Context ctx, int txtViewResourceId,
                          LiteratureArrayInfo[] objects) {
            super(ctx, txtViewResourceId, objects);
        }

        @Override
        public View getDropDownView(int position, View cnvtView, ViewGroup prnt) {
            return getCustomView(position, cnvtView, prnt);
        }

        @Override
        public View getView(int pos, View cnvtView, ViewGroup prnt) {
            return getCustomView(pos, cnvtView, prnt);
        }

        public View getCustomView(int position, View convertView,
                                  ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View mySpinner = inflater.inflate(R.layout.custom_spinner,
                    parent, false);
            TextView main_text = (TextView) mySpinner
                    .findViewById(R.id.text_main_seen);
            main_text.setText(litInfo[position].lt);

            return mySpinner;
        }
    }

    public class SampleAdapter extends
            ArrayAdapter<SampleArrayInfo> {
        public SampleAdapter(Context ctx, int txtViewResourceId,
                             SampleArrayInfo[] objects) {
            super(ctx, txtViewResourceId, objects);
        }

        @Override
        public View getDropDownView(int position, View cnvtView, ViewGroup prnt) {
            return getCustomView(position, cnvtView, prnt);
        }

        @Override
        public View getView(int pos, View cnvtView, ViewGroup prnt) {
            return getCustomView(pos, cnvtView, prnt);
        }

        public View getCustomView(int position, View convertView,
                                  ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View mySpinner = inflater.inflate(R.layout.custom_spinner,
                    parent, false);
            TextView main_text = (TextView) mySpinner
                    .findViewById(R.id.text_main_seen);
            main_text.setText(sampleInfo[position].sm);

            return mySpinner;
        }
    }

    public class GiftAdapter extends
            ArrayAdapter<GiftArrayInfo> {
        public GiftAdapter(Context ctx, int txtViewResourceId,
                           GiftArrayInfo[] objects) {
            super(ctx, txtViewResourceId, objects);
        }

        @Override
        public View getDropDownView(int position, View cnvtView, ViewGroup prnt) {
            return getCustomView(position, cnvtView, prnt);
        }

        @Override
        public View getView(int pos, View cnvtView, ViewGroup prnt) {
            return getCustomView(pos, cnvtView, prnt);
        }

        public View getCustomView(int position, View convertView,
                                  ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View mySpinner = inflater.inflate(R.layout.custom_spinner,
                    parent, false);
            TextView main_text = (TextView) mySpinner
                    .findViewById(R.id.text_main_seen);
            main_text.setText(giftInfo[position].gft);

            return mySpinner;
        }
    }


    private class MasterDataTask implements Runnable {


        MasterDataTask() {
        }


        @Override
        public void run() {


            try {
                URL url = new URL(Url);
                masterserverResponse = httpClass.httpGetConnection(url);

                JSONObject mastercalculateInfoJSON = new JSONObject(masterserverResponse);


                productGroupArrayList.add(new ProductGroupArrayInfo("", "Choose"));
                JSONArray vehicleTypesArray = mastercalculateInfoJSON
                        .getJSONArray("product_group_list");
                for (int j = 0; j < vehicleTypesArray.length(); j++) {
                    JSONObject vehicleTypes = vehicleTypesArray
                            .getJSONObject(j);
                    String id = vehicleTypes.getString("id");
                    String product_group = vehicleTypes.getString("product_group");

                    productGroupArrayList.add(new ProductGroupArrayInfo(id, product_group));
                }


                literatureArrayList.add(new LiteratureArrayInfo("", "Choose"));
                JSONArray brandsArray = mastercalculateInfoJSON
                        .getJSONArray("literature_list");
                for (int j = 0; j < brandsArray.length(); j++) {
                    JSONObject brandsTypes = brandsArray
                            .getJSONObject(j);
                    String id = brandsTypes.getString("id");
                    String literature = brandsTypes.getString("literature");

                    literatureArrayList.add(new LiteratureArrayInfo(id, literature));
                }


                sampleArrayList.add(new SampleArrayInfo("", "Choose"));
                JSONArray brandModelsArray = mastercalculateInfoJSON
                        .getJSONArray("physician_sample_list");
                for (int j = 0; j < brandModelsArray.length(); j++) {
                    JSONObject brandModels = brandModelsArray
                            .getJSONObject(j);
                    String id = brandModels.getString("id");
                    String sample = brandModels.getString("sample");

                    sampleArrayList.add(new SampleArrayInfo(id, sample));
                }


                giftArrayList.add(new GiftArrayInfo("", "Choose"));
                JSONArray vehicleClassesArray = mastercalculateInfoJSON
                        .getJSONArray("gift_list");
                for (int j = 0; j < vehicleClassesArray.length(); j++) {
                    JSONObject vehicleClassesModels = vehicleClassesArray
                            .getJSONObject(j);
                    String id = vehicleClassesModels.getString("id");
                    String gift = vehicleClassesModels.getString("gift");

                    giftArrayList.add(new GiftArrayInfo(id, gift));
                }


                Result = "";

            } catch (Exception ex) {
                Result = "Exception";
            }


            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (Result.equals("Exception")) {
                        alert.ExceptionAlertDialog(InternDCR.this);
                    } else {
                        groupList();
                        litList();
                        sampleList();
                        GiftList();
                    }
                }
            });
        }

    }


}