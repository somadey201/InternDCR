package com.soma.interndcr;

class SampleArrayInfo {
    String id, sm;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getsm() {
        return sm;
    }

    public void setsm(String sm) {
        this.sm = sm;
    }

    public SampleArrayInfo(String id, String product_group) {
        this.id = id;
        this.sm = product_group;
    }
}
