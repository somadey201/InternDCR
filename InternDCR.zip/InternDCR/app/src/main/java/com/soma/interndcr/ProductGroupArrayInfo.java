package com.soma.interndcr;

class ProductGroupArrayInfo {
    String id, pg;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPg() {
        return pg;
    }

    public void setPg(String pg) {
        this.pg = pg;
    }

    public ProductGroupArrayInfo(String id, String product_group) {
        this.id = id;
        this.pg = product_group;
    }
}
