package com.soma.interndcr;

class LiteratureArrayInfo {
    String id, lt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getlt() {
        return lt;
    }

    public void setlt(String lt) {
        this.lt = lt;
    }

    public LiteratureArrayInfo(String id, String product_group) {
        this.id = id;
        this.lt = product_group;
    }
    
}
