package com.soma.interndcr;

public class Configuration {

    public static final String HTTP = "https";
    public static final String BASE_URL = "https://raw.githubusercontent.com/";
}
