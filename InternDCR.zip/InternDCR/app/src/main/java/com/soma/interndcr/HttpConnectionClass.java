package com.soma.interndcr;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Created by Rajesh on 11/23/2017.
 */

public class HttpConnectionClass {
    String serverResponse = "";

    private Context context;

    public HttpConnectionClass(Context context) {
        this.context = context;
    }

    public String httpGetConnection(URL url) {
        if (Configuration.HTTP.toLowerCase().equals("https")) {
            try {
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public X509Certificate[] getAcceptedIssuers() {
                                return new X509Certificate[0];
                            }

                            public void checkClientTrusted(X509Certificate[] certs, String authType) {
                            }

                            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                                try {
                                    chain[0].checkValidity();
                                } catch (Exception e) {
                                    throw new CertificateException("Certificate not valid or trusted.");
                                }
                            }
                        }};


                HostnameVerifier hv = new HostnameVerifier() {
                    public boolean verify(String hostname, SSLSession session) {
                        HostnameVerifier hv = HttpsURLConnection
                                .getDefaultHostnameVerifier();
                        boolean rightHost = hv.verify("githubusercontent.com", session);
                        if (rightHost == true) {
                            //Log.e("true.....", String.valueOf(rightHost));
                        } else {
                            //Log.e("false.....", String.valueOf(rightHost));
                        }
                        return rightHost;
                        //return true;
                    }
                };

                SSLContext sc = SSLContext.getInstance("SSL");
                sc.init(null, trustAllCerts, new SecureRandom());
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.setSSLSocketFactory(sc.getSocketFactory());
                conn.setHostnameVerifier(hv);

                InputStream is = conn.getInputStream();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(
                                    conn.getInputStream()));
                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        sb.append(line);
                       // break;
                    }

                    in.close();
                    serverResponse = sb.toString();

                }

            } catch (Exception ex) {
                String yy = ex.toString();
            }

        }

        return serverResponse;
    }
}
