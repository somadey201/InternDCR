package com.soma.interndcr;

class GiftArrayInfo {
    String id, gft;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getgft() {
        return gft;
    }

    public void setgft(String gft) {
        this.gft = gft;
    }

    public GiftArrayInfo(String id, String product_group) {
        this.id = id;
        this.gft = product_group;
    }
}
