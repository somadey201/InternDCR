package com.soma.interndcr;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AlertDialogManager {
    Context context;
    Class intentContext;


    public void InternetAlertDialog(final Context context) {
        new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Attention!")
                .setContentText("<p>" + "Please connect to Internet" + "</p>")
                .setConfirmText("Ok")
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();
                        sDialog.dismiss();
                    }
                })
                .show();
    }


    public void ExceptionAlertDialog(Context context) {
        final SweetAlertDialog dialog = new SweetAlertDialog(context, SweetAlertDialog.WARNING_TYPE);
        dialog.setTitleText("Attention!");
        dialog.setContentText("<p>" + "Sorry, the request cannot be processed at this moment." + "</p>");
        dialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }


}
